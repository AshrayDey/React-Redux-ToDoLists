const { createSlice } = require("@reduxjs/toolkit");

const initialState = { todos: [], completedTodos: [] };

const todoSlice = createSlice({
  name: "todo",
  initialState: initialState,
  reducers: {
    add: (state, action) => {
      state.todos.push(action.payload);
    },
    deleteTodo: (state, action) => {
      state.todos.splice(action.payload, 1);
    },
    completed: (state, action) => {
      state.completedTodos.push(state.todos[action.payload]);
      state.todos.splice(action.payload, 1);
    },
    deleteCompleted: (state, action) => {
      state.completedTodos.splice(action.payload, 1);
    }
  },
});

export const todoReducer = todoSlice.reducer;
export const todoSelector = (state) => state.todoReducer;
// export const completedSelector = (state) => state.todoReducer.completedTodos;
export const {add,completed,deleteCompleted,deleteTodo} = todoSlice.actions;

import { Provider } from "react-redux";
import "./App.css";
import { TodoPage } from "./components/TodoPage/todoPage";


function App() {
  return (
    <div className="App">
      <h1>MY TODOS</h1>
      {/* <Provider store={store}>
       
      </Provider> */}
      <TodoPage />
    </div>
  );
}

export default App;

import { MdDeleteOutline } from "react-icons/md";
import styles from "./completedTodos.module.scss";
export const Completed = () => {
  return (
    <>
      <div className={styles.container}>
        <h1>COMPLETED</h1>
        <div >

          <div className={styles.task}>
            <h3>Title of task</h3>
            <h4>Completed on day/month/time</h4>
          </div>

          <div className={styles.option}>
            <MdDeleteOutline className={styles.delete} />
          </div>

        </div>
      </div>
    </>
  );
};

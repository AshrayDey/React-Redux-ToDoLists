import { Completed } from "../CompletedTab/completedTodos";
import { TodoForm } from "../TodoForm/todoForm";
import { Todos } from "../Todos/todos";

import styles from "./todoPage.module.scss";
import React, { useState } from "react";
export const TodoPage = () => {
  const [todoScreen, setTodoScreen] = useState(true);
  return (
    <>
      <div className={styles.container}>
        <TodoForm />
        <div className={styles.tabs}>
          <button
            className={styles.todoTab}
            onClick={() => setTodoScreen(true)}
            style={todoScreen ? { backgroundColor: "rgba(255, 0, 0, 0.637)" } : {}}
          >
            Todo
          </button>
          <button
            className={styles.completedTab}
            onClick={() => setTodoScreen(false)}
            style={!todoScreen ? { backgroundColor: "rgba(255, 0, 0, 0.637)" } : {}}
          >
            Completed
          </button>
          
        </div>
        
        
        {
          (todoScreen?<Todos />:<Completed/>)
        }
      </div>
    </>
  );
};

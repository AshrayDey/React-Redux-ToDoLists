
import styles from "./todoForm.module.scss";


export const TodoForm = () => {
  // const todos=useSelector()
  function handleAdd(){
    
    
  }
  return (
    <>
      <div className={styles.formContainer}>
        <div className={styles.todoInput}>
          <div className={styles.title}>
            <label htmlFor="">Title</label>
            <input type="text" placeholder="Title?" />
          </div>

          <div className={styles.description}>
            <label htmlFor="">Description</label>
            <input type="text" placeholder="What's the task description?" />
          </div>

          <div>
            <button >ADD</button>
          </div>
        </div>

       
      </div>
    </>
  );
};
